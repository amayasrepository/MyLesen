MyLesen 2022
Created By Programophobia 

The "main" folder simply shows the prototype's interface with little functionality.
It has two main sections, the index/login/signup 
and the homepage that connects the user to all the available functions as of now.

to view the index/login/signup partition please visit index.html
to view the homepage please visit homepage.html


