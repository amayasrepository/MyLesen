<?PHP
# memulakan fungsi session
session_start();
# menghapuskan nilai pembolehubah session
session_unset();
# menghentikan fungsi session
session_destroy();
if(!empty($_GET))
{
    if($_GET['id']="admin");
    header("location:admin/kpp.php");
}
else
{
    header("location:kpp.php");
}
?>
