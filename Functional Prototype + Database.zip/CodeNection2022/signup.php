<!--Memanggil fail header-->
<?PHP include('header.php'); ?>
<div class="w3-row w3-margin-bottom ">
    <div class="w3-quarter w3-container w3-margin-top w3-margin-bottom ">

        <div class="w3-container w3-white w3-card-2 w3-round-large w3-animate-left">
            <h4>Student Registration</h4>

            <form class='w3-margin' action='' method='POST'>
                <label><br>Student Name</br></label> <input class='w3-select w3-input w3-border w3-round-xxlarge' type='text' name='studentName'>
                <label><br>Student ID (NRIC)</br></label> <input class='w3-select w3-input w3-border w3-round-xxlarge' type='text' name='studentID'>
                <label><br>Class Type</br></label> <input class='w3-select w3-input w3-border w3-round-xxlarge' type='text' name='classType'>
                <label><br>Student Password</br></label> <input  class='w3-select w3-input w3-border w3-round-xxlarge' type='password' name='studentPassword'>
                <hr>
                <input class="w3-button w3-bar w3-red w3-round-xxlarge" type='submit' value='Sign Up'>
            </form>

        </div>
    </div>

    <div class="w3-threequarter ">
        <img src='images/index.jpg' class='w3-image w3-right' >
    </div>
</div>
<?PHP
# menyemak kewujudan data POST
if (!empty($_POST))
{
    # memanggil fail connection
    include ('connection.php');

    # mengambil data POST
    $studentName=$_POST['studentName'];
    $studentID=$_POST['studentID'];
    $classType=$_POST['classType'];
    $studentPassword=$_POST['studentPassword'];

    # -- data validation --
    if(empty($studentName) or empty($studentID) or empty($classType) or empty($studentPassword))
    {
        die("<script>alert('Complete the necessary information.');
        window.history.back();</script>");
    }

    # --- data validation
    if(strlen($studentID)!=12 or !is_numeric($studentID))
    {
        die("<script>alert('Error on NRIC');
        window.history.back();</script>");
    }

    # arahan SQL untuk menyimpan data
    $arahan_sql_simpan="insert into student
    (studentName, studentID, classType, studentPassword)
    values
    ('$studentName','$studentID','$classType','$studentPassword')";

    # melaksanakan proses menyimpan dalam syarat if
    if(mysqli_query($condb,$arahan_sql_simpan))
    {
        # jika proses menyimpan berjaya. papar info dan buka laman penumpang_login.php
        echo "<script>alert('Registration Completed!');
        window.location.href='login.php';</script>";
    }
    else
    {
        # jika proses menyimpan gagal, kembali ke laman sebelumnya
        echo "<script>alert('Registration Failed');
        window.history.back();</script>";
    }
}
?>