<?PHP
# Memulakan fungsi Session
session_start();
date_default_timezone_set("Asia/Kuala_Lumpur");
# Mendapatkan tarikh hari ini dan esok
$today=date("Y/m/d");
$tomorrow=date('Y/m/d', strtotime(' +1 day'));

#----------------- Bahagian login & logout Session ------------
$filename = basename($_SERVER['PHP_SELF']);
if(($filename !='kpp.php' and $filename !='confirm.php' and $filename !='jpj.php'  and $filename !='jpjProcess.php' and $filename !='receipt.php' and $filename !='result.php' and $filename !='signup.php' and $filename !='login.php')  and empty($_SESSION['mylesen']))
{
    die("<script>alert('Please Log In');window.location.href='logout.php';</script>");
}
?>
<!DOCTYPE html>
<html>
<title>MyLesen</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-flat.css">
    <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-ios.css">
    <link rel="stylesheet" href="style/w3.css">
    <!-- Tajuk di atas -->
    <div class="w3-container w3-ios-deep-blue">
        <h1>MyLesen</h1>
    </div>

<!-- Navigasi -->
<?PHP

# Link Ke laman utama
echo"<div class='w3-bar w3-black'>
<a href='kpp.php' class='w3-bar-item w3-button'>Book KPP Session</a>";
echo"<div class='w3-bar w3-black'>
<a href='result.php' class='w3-bar-item w3-button'>JPJ Result</a>";

# menyemak kewujudan session nama_penumpang (jika telah login, maka session ini akan mempunyai nilai)
if(empty($_SESSION['studentName']))
{
    # papar Link untuk login dan daftar pengguna baru jika pengguna masih belum login
    echo"<a href='login.php' class='w3-bar-item w3-button'>Login</a>
    <a href='signup.php' class='w3-bar-item w3-button'>Sign Up</a>";
}
else
{
    # papar link logot jika pengguna telah login
    echo "<a href='logout.php' class='w3-bar-item w3-button w3-right w3-hover-red w3-flat-alizarin'>Logout</a>";
}
echo "</div>";
?>