<?PHP
# memanggil fail header.php
include('header.php');
# nilai session['nokp_penyewa'] empty atau tidak
if(empty($_SESSION['studentID']))
{
    # jika nilai session['nokp_penyewa'] empty. bermaksud penyewa belum login
    die("<script>alert('Please login before continuing booking');
    window.location.href='login.php';</script>");
}
# memanggil fail connection.php
include('connection.php');
$instructorName=$_POST['instructorName'];
$day=$_POST['day'];
$time=$_POST['time'];
# menyemak kewujudan data GET
if(!empty($_GET))
{
    # Mengumpukan data GET kepada tatasusunan
    $data_get= array(
        'studentName'=>$record['studentName'],
        'studentID'=>$record['studentID'],
        'classType'=>$record['classType'],
        'day'=>$day,
        'time'=>$time,
        'instructorName'=>$instructorName
    );
}
?>
    <div class="w3-row">
        <div class="w3-quarter w3-container ">
        </div>
        <div class="w3-half w3-container w3-margin-top w3-card-2 ">
            <div class='w3-margin w3-animate-opacity'>
                <!-- Memaparkan semua maklumat tempahan -->
                <h4>Booking Details</h4><hr>
                <p><b>Student Details</b></p>
                <label><b>Student Name : </b></label><?PHP echo $_SESSION['studentName']; ?> <br>
                <label><b>Student ID : </b></label><?PHP echo $_SESSION['studentID']; ?> <br>
                <label><b>Class Type : </b></label><?PHP echo $_SESSION['classType']; ?> <br>
                <!-- borang untuk Pembayaran (tidak wajib) -->
            </div>
        </div>
        <div class="w3-quarter w3-container">
        </div>
    </div>
    <h4>Book your JPJ Test</h4>
    <form class='w3-margin' action='jpj.php' method='POST'>
        <input class="w3-button w3-flat-green-sea w3-bar w3-round-xxlarge" type='submit' value='Submit'>
    </form>
<?PHP include ('footer.php'); ?>