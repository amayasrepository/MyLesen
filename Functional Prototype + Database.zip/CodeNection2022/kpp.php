<?PHP
# memanggil fail header.php dan connection.php
include('header.php');
include('connection.php');

# Mencari data slot untuk diumpukan kepada dropdown list
$search_day="select* from slotday";
$execute_search_day=mysqli_query($condb,$search_day);
$search_time="select* from slottime";
$execute_search_time=mysqli_query($condb,$search_time);
$search_instructor="select* from instructor";
$execute_search_instructor=mysqli_query($condb,$search_instructor);
$list_instructor='';
$list_day='';
$list_time='';
while($record=mysqli_fetch_array($execute_search_instructor))
{
    $list_instructor=$list_instructor."<option value='".$record['instructorName']."'>".$record['instructorName']."</option>";
}

while($record=mysqli_fetch_array($execute_search_day))
{
    $list_day=$list_day."<option value='".$record['day']."'>".$record['day']."</option>";
}
while($record=mysqli_fetch_array($execute_search_time))
{
    $list_time=$list_time."<option value='".$record['time']."'>".$record['time']."</option>";
}
?>

<!-- row tengah-->
<div class="w3-row w3-margin-bottom ">
    <!-- column pertama -->
    <div class="w3-quarter w3-container w3-margin-top w3-margin-bottom ">

        <div class="w3-container w3-white w3-card-2 w3-round-large w3-animate-left">
            <h4>Driving Class Session Search</h4>
            <form class='w3-margin' action='confirm.php' method='POST'>
                <label><b>Day</b></label>
                <select class='w3-select w3-input w3-border w3-round-xxlarge' name='day'>
                    <?PHP echo $list_day; ?>
                </select>
                <label><b>Time</b></label>
                <select class='w3-select w3-input w3-border w3-round-xxlarge' name='time'>
                    <?PHP echo $list_time; ?>
                </select>
                <hr>
                <label><b>Instructor</b></label>
                <select class='w3-select w3-input w3-border w3-round-xxlarge' name='instructorName'>
                    <?PHP echo $list_instructor; ?>
                </select>
                <hr>
                <input class="w3-button w3-flat-green-sea w3-bar w3-round-xxlarge" type='submit' value='Submit'>
            </form>
        </div>
    </div>
</div>
