<?PHP
# memanggil fail header.php dan connection.php
include('header.php');
?>
<!DOCTYPE html>
<html>
<body>

<?php
$d=strtotime("next Tuesday");
?>
<div class="w3-row">
    <div class="w3-quarter w3-container ">
    </div>
    <div class="w3-half w3-container w3-margin-top w3-card-2 ">
        <div class='w3-margin w3-animate-opacity'>
            <!-- Memaparkan semua maklumat tempahan -->
            <h4>JPJ Details</h4><hr>
            <p><b>Student Details</b></p>
            <label><b>Student Name : </b></label><?PHP echo $_SESSION['studentName']; ?> <br>
            <label><b>Student ID : </b></label><?PHP echo $_SESSION['studentID']; ?> <br>
            <label><b>Class Type : </b></label><?PHP echo $_SESSION['classType']; ?> <br>
            <label><b>Your JPJ Date : </b></label><?PHP echo date("Y-m-d", $d) ?> <br>
        </div>
    </div>
    <div class="w3-quarter w3-container">
    </div>
</div>

</body>
</html>
<?PHP include ('footer.php'); ?>
