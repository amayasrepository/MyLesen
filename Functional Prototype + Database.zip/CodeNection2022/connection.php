<?PHP

$condb=mysqli_connect("localhost","root","root123","mylesen");
?>