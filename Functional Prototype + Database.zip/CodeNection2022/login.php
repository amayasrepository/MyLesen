<!--Memanggil fail header-->
<?PHP include('header.php'); ?>

<!--Menyediakan form bagi daftar masuk pengguna baru-->
<!-- isi kandungan --><div class="w3-row w3-light-blue w3-margin-bottom ">
    <div class="w3-quarter w3-container w3-margin-top w3-margin-bottom ">

        <div class="w3-container w3-white w3-card-2 w3-round-large w3-animate-left">
            <h4>Student Login</h4>
            <form class='w3-margin' action='' method='POST'>
                <label class="w3-text-blue"><b>Student ID (NRIC)</b></label>
                <input class='w3-input w3-border w3-round-xxlarge' type='text' name='studentID'>

                <label class="w3-text-blue"><b>Password</b></label>
                <input class='w3-input w3-border w3-round-xxlarge' type='password' name='studentPassword'>
                <br>
                <input  class="w3-button w3-round-xxlarge w3-red w3-bar" type='submit' value='Log In'>
            </form>
        </div>
    </div>
    <div class="w3-threequarter ">
        <img src='images/bg-car2.jpg' class='w3-image w3-opacity-min'>
    </div>
</div>
<?PHP
# menyemak kewujudan data POST
if (!empty($_POST))
{
    # memanggil fail connection
    include ('connection.php');

    # mengambil data POST
    $studentID=$_POST['studentID'];
    $studentPassword=$_POST['studentPassword'];

    # arahan SQL untuk mencari data dari jadual penyewa
    $arahan_sql_cari="select* 
    from student 
    where studentID='$studentID' and studentPassword='$studentPassword'
    limit 1 ";

    # melaksanakan proses carian
    $laksana_arahan=mysqli_query($condb,$arahan_sql_cari);

    # jika terdapat 1 baris rekod di temui
    if(mysqli_num_rows($laksana_arahan)==1)
    {
        # login berjaya

        # pembolehubah $rekod mengambil data yang di temui semasa proses mencari
        $record=mysqli_fetch_array($laksana_arahan);

        #mengumpukkan kepada pembolehubah session
        $_SESSION['studentName']=$record['studentName'];
        $_SESSION['studentID']=$record['studentID'];
        $_SESSION['classType']=$record['classType'];

        # mengarahkan fail index.php dibuka
        echo "<script>window.location.href='kpp.php';</script>";
    }
    else
    {
        # login gagal. kembali ke laman sebelumnya
        echo "<script>alert('Log In failed');
        window.history.back();</script>";
    }
}
?>