<?PHP
# memanggil fail header.php dan connection.php
include('header.php');
?>

<!-- row tengah-->
    <div class="w3-row w3-margin-bottom ">
        <!-- column pertama -->
    <br class="w3-quarter w3-container w3-margin-top w3-margin-bottom ">
    <label><b>KPP2 : LULUS</b></label>
        <br></br>
    <label><b>KPP3 : KANDAS </b></label>

    </div>
    </div>
<?PHP include('footer.php'); ?>